module.exports = {
    devServer: {
        proxy: ''

    }
}