<template>
<div class="container">
    <div class="card" style="width: 20rem;margin-left: -10px;border-radius:10px;background-color:#eee;">
        <div class="card-body">
            <div class="row">
                <div class="col-lg-3">
                    <div class="list-inline-item ">

                        <img src="https://avatarfiles.alphacoders.com/131/131892.jpg" alt="">
                    </div>
                </div>
                <div class="col-lg-9">
                    <div class="text-news">
                        <h6>This is the altest</h6>
                        <p>@Nikesh kumar</p>
                    </div>
                </div>
            </div>
            <div class="hmm"></div>
            <div class="row mt-2">
                <div class="col-lg-3">
                    <div class="list-inline-item ">

                        <img src="https://avatarfiles.alphacoders.com/131/131892.jpg" alt="">
                    </div>
                </div>
                <div class="col-lg-9">
                    <div class="text-news">
                        <h6>This is the altest</h6>
                        <p>@Nikesh kumar</p>
                    </div>
                </div>
            </div>
            <div class="hmm"></div>
            <div class="row mt-2">
                <div class="col-lg-3">
                    <div class="list-inline-item ">

                        <img src="https://avatarfiles.alphacoders.com/131/131892.jpg" alt="">
                    </div>
                </div>
                <div class="col-lg-9">
                    <div class="text-news">
                        <h6>This is the altest</h6>
                        <p>@Nikesh kumar</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="card mt-2" style="width: 20rem;margin-left: -10px;border-radius:10px;background-color:#eee;">
        <div class="card-body">
            <div class="row">
                <div class="col-lg-3">
                    <div class="list-inline-item ">

                        <img src="https://avatarfiles.alphacoders.com/131/131892.jpg" alt="">
                    </div>
                </div>
                <div class="col-lg-9">
                    <div class="text-news">
                        <h6>Nikesh Kumar</h6>
                        <div class="new-folow">
                            <a>Follow</a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="hmm"></div>
            <div class="row mt-2">
                <div class="col-lg-3">
                    <div class="list-inline-item ">

                        <img src="https://avatarfiles.alphacoders.com/131/131892.jpg" alt="">
                    </div>
                </div>
                <div class="col-lg-9">
                    <div class="text-news">
                        <h6>Vipin Chandra</h6>
                        <div class="new-folow">
                            <a>Follow</a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="hmm"></div>
            <div class="row mt-2">
                <div class="col-lg-3">
                    <div class="list-inline-item ">

                        <img src="https://avatarfiles.alphacoders.com/131/131892.jpg" alt="">
                    </div>
                </div>
                <div class="col-lg-9">
                    <div class="text-news">
                        <h6>Vipin Chandra</h6>
                        <div class="new-folow">
                            <a>Follow</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
 
</div>
</template>
<script>
export default {

}
</script>

<style>
.list-inline-item img {
    height: 50px;
    width: 50px;
    border-radius: 50%;  
    margin-left: -14px;
    margin-top: 6px;
}

.text-news h6 {
    font-weight: 500;
    text-align: left;
    font-size: 16px;
}

.text-news p {
    font-weight: 600;
    text-align: left;
    font-size: 14px;
    margin-top: -8px;
}
.new-folow{
    height: 40px;
    width: 90px;
    border: 1px solid #1d9bf0;
    line-height: 36px;
    border-radius: 8px;
    margin-bottom: 5px;
}
.text-news a {
    font-weight: 600;
    text-align: left;
    font-size: 14px;
    margin-top: 2px;
    color:#1d9bf0 !important;
}
.hmm{
    border: 0;
  height: 1px;
  background-image: linear-gradient(to right, rgba(0, 0, 0, 0), rgba(0, 0, 0, 0.75), rgba(0, 0, 0, 0));

}


</style>
